﻿function OptionItem(key, val) {
    var instance = this;
    instance.key = key;
    instance.val = val;
}