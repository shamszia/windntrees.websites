﻿function OptionItemKeyVal(data) {
    var instance = this;
    instance.key = data.key;
    instance.val = data.val;
}