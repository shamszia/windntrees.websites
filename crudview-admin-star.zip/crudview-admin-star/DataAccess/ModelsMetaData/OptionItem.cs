namespace DataAccess.Core.Models {

    public class OptionItem {

        public string key { get; set; }
        public string val { get; set; }        
    }
}