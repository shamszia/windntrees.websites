﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Core.Models
{
    class AspNetUsersRoles
    {
    }
}
