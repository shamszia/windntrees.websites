﻿function UserRole(data) {
    var instance = this;
    instance.RoleId = data.RoleId;
    instance.UserId = data.UserId;
}